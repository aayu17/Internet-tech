const http = require("http")
const fs = require("fs")
const mysql = require("mysql")

var init = () => {
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "password",
        port: 3308,
    });

    con.connect(function (err) {
        if (err) throw err;
        console.log("Connected!");
        con.query("CREATE DATABASE IF NOT EXISTS ques11;", function (err, result) {
            if (err) throw err;
            // console.log("Database created");
        });
        con.query("USE ques11;", function (err, result) {
            if (err) throw err;
            // console.log("Database selected");
        });
        con.query("CREATE TABLE IF NOT EXISTS usersData (username varchar(20), password varchar(30));", function (err, result) {
            if (err) throw err;
            // console.log("Table created");
        });

        con.end();
    });
}


function dosignin(req, res) {
    var qs = new URLSearchParams(req.url.split("?")[1]);
    var username = qs.get("username");
    var passwd = qs.get("password");
    console.log(username, passwd)
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        port: 3308,
        password: "password",
        database: "ques11",
    });

    con.connect(function (err) {
        if (err) throw err;
        con.query(
            "SELECT * FROM usersData where username =? and password=?",
            [username, passwd],
            function (err, result, fields) {
                if (err) throw err;
                console.log(result);
                if (result.length >= 1) {
                    res.write("<h1>Sign In Successful</h1>");
                    res.end();
                } else {
                    res.write("<h1>Sign In Failed</h1>");
                    res.end();
                }
            }
        );
    });
}

function dosignup(req, res) {
    var body = "";
    // for GET
    // var qs = new URLSearchParams(req.url.split("?")[1]);
    // var username = qs.get("username");
    // var passwd = qs.get("password");
    // var confpasswd = qs.get("confPassword");

    // FOR POST
    req.on("data", function (data) {
        body += data;
        console.log("Partial body: " + body);
    });
    req.on("end", function () {
        console.log("Body: " + body);
        var qs = new URLSearchParams(body);
        var username = qs.get("username");
        var passwd = qs.get("password");
        var confpasswd = qs.get("confirmPassword");
        console.log(passwd, confpasswd);

        if (passwd != confpasswd) {
            res.write("<h1>Password Mismatch</h1>");
            return res.end();
        }
        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            port: 3308,
            password: "password",
            database: "ques11",
        });

        con.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
            var sql = "INSERT INTO usersData (username,password) VALUES (?,?)";
            con.query(sql, [username, passwd], function (err, result) {
                if (err) throw err;
                console.log("1 record inserted");
                res.write("<h1>Congratulation! You have signed up successfully</h1>");
                res.end();
            });
        });
    });
}

var requestHandler = (request, response) => {
    console.log(request.url)
    var path = request.url.substring(1).split('?')[0]
    console.log(path)
    if (request.url === "/") {
        fs.readFile("index.html", function (err, data) {
            if (err) {
                return response.end("Error")
            }
            response.writeHead(200, { 'Content-Type': 'text/html' });
            response.write(data);
            return response.end();
        });
    }
    else if (path === "showLogin") {
        fs.readFile("signIn.html", function (err, data) {
            if (err) {
                return response.end("Error")
            }
            response.writeHead(200, { 'Content-Type': 'text/html' });
            response.write(data);
            response.end();
        })
    }
    else if (path === "showSignUp") {
        fs.readFile("signUp.html", function (err, data) {
            if (err) {
                return response.end("Error")
            }
            response.writeHead(200, { 'Content-Type': 'text/html' });
            response.write(data);
            response.end();
        })
    }
    else if (path === "signIn") {
        dosignin(request, response)
    }
    else if (path === "signUp") {
        dosignup(request, response)
    }
    else {
        response.writeHead(404, {
            "Content-Type": "text/html",
        });
        return response.end("Page Not Found");
    }
}

init();
const hostname = "localhost"
const port = 10001
const server = http.createServer(requestHandler)
server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});
