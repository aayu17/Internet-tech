const http = require("http")

http.createServer(function (request, response) {
    // response.write("hello")
    response.writeHead(200, { 'Content-Type': 'text/plain' });
    response.end("Hello world, This is my Node.js server");
}).listen(10000)